import javax.swing.*;

public class RegistrationForm {
    public User user;
    private JPanel panel1;
}
